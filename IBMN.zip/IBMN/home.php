<?php 
	include "config/config.php";
    session_start(); $function = new functions(); 
    $auth = $function->AuthUser($_SESSION['username']);
    $response = $function->sessionCheck();
    if($response == "false"){header("Location:index.php");}
    if(isset($_GET['logout'])){$function->logout();}
 ?>

<!DOCTYPE html>
<html>
<head>

	<title>Home</title>

    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <link href="vendor/vector-map/jqvmap.min.css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="css/sweet-alert.css">
    <link rel="stylesheet" href="css/style-home.css">
    <link href="css/theme.css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">

</head>
<body>
<div class="header-mini"></div>
    <div class="header-logo">
        
                                <div class="header-button-item mr-0 js-sidebar-btn">
                                    <i class="zmdi zmdi-menu"></i>
                                </div>

                                <div class="setting-menu js-right-sidebar d-none d-lg-block">
                                    <div class="account-dropdown__body">
                                        

                                        <div class="account-dropdown__item">
                                            <a href="?page=viewFST">
                                                Fakultas Sains dan Tekonologi</a>
                                        </div>


                                        <div class="account-dropdown__item">
                                            <a href="?page=viewFITK">
                                                Fakultas Ilmu Tarbiyah dan Keguruan</a>
                                        </div>


                                        <div class="account-dropdown__item">
                                            <a href="?page=viewFAIB">
                                                Fakultas Adab dan Ilmu Budaya</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewFEBI">
                                                Fakultas Ekonomi dan Bisnis Islam</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewFUPI">
                                                Fakultas Ushuluddin dan Pemikiran Islam</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewFDK">
                                                Fakultas Dakwah dan Komunikasi</a>
                                        </div>


                                        <div class="account-dropdown__item">
                                            <a href="?page=viewFISH">
                                                Fakultas Ilmu Sosial dan Humaniora</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewFSH">
                                                Fakultas Syari'ah dan Hukum</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewPascasarjana">
                                                Fakultas Pascasarjana</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewPerpustakaan">
                                                UPT Pusat Perpustakaan</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewBahasa">
                                                UPT Pusat Pengembangan Bahasa</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewBisnis">
                                                 UPT Pusat Pengembangan Bisnis</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewPTIPD">
                                                UPT Pusat PTIPD</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewAdmisi">
                                                Kantor Admisi</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewLP2M">
                                                Lembaga Penelitian dan Pengabdian Masyarakat</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewLPM">
                                                Lembaga Penjaminan Mutu</a>
                                        </div>


                                         <div class="account-dropdown__item">
                                            <a href="?page=viewSPI">
                                                Satuan Pengawasan Internal</a>
                                        </div>


                                        <div class="account-dropdown__item">
                                            <a href="?page=viewPAU">
                                                Pusat Administrasi Universitas</a>
                                        </div>




                                        <div class="account-dropdown__item">
                                            <a href="homepage.php?logout" id="forLogout" style="color: red;">
                                                <i class="zmdi zmdi-power"></i>Log out </a>
                                        </div>
                                    </div>
                                </div>

        <img src="gambar/logo-uin.png">
        <div class="text-logo">Inventaris Barang Milik Negara</div>
    </div>

	<div class="page-wrapper">
		

		<div class="page-container2">
			<header class="header-desktop2">

                    <div class="container-fluid">
                
                            </div>
                        </div>
                    </div>

            </header>

			<?php 

                @$page = $_GET['page'];
                switch($page){


                    case 'viewFST':
                        include "admin/FST/viewFST.php";
                        break;
                    case 'addFST':
                        include "admin/FST/addFST.php";
                        break;
                    case 'editFST':
                        include "admin/FST/editFST.php";
                        break;


                    case 'viewFEBI':
                        include "admin/FEBI/viewFEBI.php";
                        break;
                    case 'addFEBI':
                        include "admin/FEBI/addFEBI.php";
                        break;
                    case 'editFEBI':
                        include "admin/FEBI/editFEBI.php";
                        break;


                    case 'viewAdmisi':
                        include "admin/Admisi/viewAdmisi.php";
                        break;
                    case 'addAdmisi':
                        include "admin/Admisi/addAdmisi.php";
                        break;
                    case 'editAdmisi':
                        include "admin/Admisi/editAdmisi.php";
                        break;


                    case 'viewBahasa':
                        include "admin/Bahasa/viewBahasa.php";
                        break;
                    case 'addBahasa':
                        include "admin/Bahasa/addBahasa.php";
                        break;
                    case 'editBahasa':
                        include "admin/Bahasa/editBahasa.php";
                        break;


                    case 'viewBisnis':
                        include "admin/Bisnis/viewBisnis.php";
                        break;
                    case 'addBisnis':
                        include "admin/Bisnis/addBisnis.php";
                        break;
                    case 'editBisnis':
                        include "admin/Bisnis/editBisnis.php";
                        break;


                    case 'viewFAIB':
                        include "admin/FAIB/viewFAIB.php";
                        break;
                    case 'addFAIB':
                        include "admin/FAIB/addFAIB.php";
                        break;
                    case 'editFAIB':
                        include "admin/FAIB/editFAIB.php";
                        break;


                    case 'viewFDK':
                        include "admin/FDK/viewFDK.php";
                        break;
                    case 'addFDK':
                        include "admin/FDK/addFDK.php";
                        break;
                    case 'editFDK':
                        include "admin//editFDK.php";
                        break;


                    case 'viewFISH':
                        include "admin/FISH/viewFISH.php";
                        break;
                    case 'addFISH':
                        include "admin/FISH/addFISH.php";
                        break;
                    case 'editFISH':
                        include "admin/FISH/editFISH.php";
                        break;


                    case 'viewFITK':
                        include "admin/FITK/viewFITK.php";
                        break;
                    case 'addFITK':
                        include "admin/FITK/addFITK.php";
                        break;
                    case 'editFITK':
                        include "admin/FITK/editFITK.php";
                        break;


                    case 'viewFSH':
                        include "admin/FSH/viewFSH.php";
                        break;
                    case 'addFSH':
                        include "admin/FSH/addFSH.php";
                        break;
                    case 'editFSH':
                        include "admin/FSH/editFSH.php";
                        break;


                    case 'viewFUPI':
                        include "admin/FUPI/viewFUPI.php";
                        break;
                    case 'addFUPI':
                        include "admin/FUPI/addFUPI.php";
                        break;
                    case 'editFUPI':
                        include "admin/FUPI/editFUPI.php";
                        break;


                    case 'viewLP2M':
                        include "admin/LP2M/viewLP2M.php";
                        break;
                    case 'addLP2M':
                        include "admin/LP2M/addLP2M.php";
                        break;
                    case 'editLP2M':
                        include "admin/LP2M/editLP2M.php";
                        break;


                    case 'viewLPM':
                        include "admin/LPM/viewLPM.php";
                        break;
                    case 'addLPM':
                        include "admin/LPM/addLPM.php";
                        break;
                    case 'editLPM':
                        include "admin/LPM/editLPM.php";
                        break;


                    case 'viewPascasarjana':
                        include "admin/Pascasarjana/viewPascasarjana.php";
                        break;
                    case 'addPascasarjana':
                        include "admin/Pascasarjana/addPascasarjana.php";
                        break;
                    case 'editPascasarjana':
                        include "admin/Pascasarjana/editPascasarjana.php";
                        break;


                    case 'viewPAU':
                        include "admin/PAU/viewPAU.php";
                        break;
                    case 'addPAU':
                        include "admin/PAU/addPAU.php";
                        break;
                    case 'editPAU':
                        include "admin/PAU/editPAU.php";
                        break;


                    case 'viewPerpustakaan':
                        include "admin/Perpustakaan/viewPerpustakaan.php";
                        break;
                    case 'addPerpustakaan':
                        include "admin/Perpustakaan/addPerpustakaan.php";
                        break;
                    case 'editPerpustakaan':
                        include "admin/Perpustakaan/editPerpustakaan.php";
                        break;


                    case 'viewPTIPD':
                        include "admin/PTIPD/viewPTIPD.php";
                        break;
                    case 'addPTIPD':
                        include "admin/PTIPD/addPTIPD.php";
                        break;
                    case 'editPTIPD':
                        include "admin/PTIPD/editPTIPD.php";
                        break;


                    case 'viewSPI':
                        include "admin/SPI/viewSPI.php";
                        break;
                    case 'addSPI':
                        include "admin/SPI/addSPI.php";
                        break;
                    case 'editSPI':
                        include "admin/SPI/editSPI.php";
                        break;


                    default:
                        $page = "viewFST";
                        include "admin/FST/viewFST.php";
                        break;
                 
                }
             ?>
		</div>
	</div>


    <script src="vendor/jquery-3.2.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="vendor/slick/slick.min.js"></script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js"></script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/vector-map/jquery.vmap.js"></script>
    <script src="vendor/vector-map/jquery.vmap.min.js"></script>
    <script src="vendor/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="vendor/vector-map/jquery.vmap.world.js"></script>
    <script src="js/main.js"></script>
    <script src="js/sweetalert.min.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    
    <script>
      $(document).ready(function(){
          function preview(input){
            if(input.files && input.files[0]) {
              var reader = new FileReader();
            };
    </script>
    
    <script>
      $(document).ready(function(){
        $('#forLogout').click(function(e){
          e.preventDefault();
            swal({
            title: "Log out",
            type: "info",
            showCancelButton: true,
            confirmButtonText: "Ya",
            cancelButtonText: "Tidak",
            closeOnConfirm: false,
            closeOnCancel: true
          }, function(isConfirm) {
            if (isConfirm) {
              window.location.href="?logout";
            }
          });
        });
      })
    </script>

    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>

	<?php include "config/alert.php"; ?>
    
</body>
</html>