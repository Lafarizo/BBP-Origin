<?php 
	$username = "root";
    $password = "";
    $database = "bbp_ibmn";
    $hostname = "localhost";
    $con = mysqli_connect($hostname,$username,$password,$database) or die("Connection Corrupt");
    $rg = new functions();


    class functions{

        public function login($username,$password){
            global $con;
            
            $sql = "SELECT * FROM table_user WHERE username ='$username'";
            $query = mysqli_query($con,$sql);
            $rows  = mysqli_num_rows($query);
            $assoc = mysqli_fetch_assoc($query);
            if($rows > 0){
                if(base64_decode($assoc['password']) == $password){
                    return ['response'=>'positive','alert'=>'Berhasil Login','level'=>$assoc['level']];
                }else{
                    return ['response'=>'negative','alert'=>'Password Salah'];    
                }
            }else{
                
                return ['response'=>'negative','alert'=>'Username atau Password Salah'];
            }
        }


        public function redirect($redirect)
        {
            return ['response'=>'positive','alert'=>'Login Berhasil','redirect'=>$redirect];   
        }


        public function logout(){
            session_destroy();
            header("Location:index.php");
        }



        public function AuthUser($sessionUser){
            global $con;
            $sql = "SELECT * FROM table_user WHERE username = '$sessionUser'";
            $query = mysqli_query($con,$sql);
            $bigData = mysqli_fetch_assoc($query);
            return $bigData;
        }


        public function querySelect($sql){
            global $con;
            $query = mysqli_query($con,$sql);
            $data = [];
            while($bigData = mysqli_fetch_assoc($query)){
                $data[] = $bigData;
            }
            return $data;
        }

        public function selectWhere($table,$where,$whereValues){
            global $con;
            $sql = "SELECT * FROM $table WHERE $where = '$whereValues'";
            $query = mysqli_query($con,$sql);
            return $data = mysqli_fetch_assoc($query);
        }

        public function edit($table,$where,$whereValues){
            global $con;
            $sql = "SELECT * FROM $table WHERE $where = '$whereValues'";
            $query = mysqli_query($con,$sql);
            $data = [];
            while($bigData = mysqli_fetch_assoc($query)){
                $data[] = $bigData;
            }
            return $data;
        }  

        public function getCountRows($table){
            global $con;
            $sql   = "SELECT * FROM $table";
            $query = mysqli_query($con,$sql);
            $rows  = mysqli_num_rows($query);
            return $rows;
        }
        
        public function sessionCheck(){
            if(!isset($_SESSION['username'])){
                
                return "false";
            }else{
                
                return "true";
            }
        }

    	public function insert($table, $values, $redirect){
    		global $con;
    		$sql   = "INSERT INTO $table VALUES($values)";
            $query = mysqli_query($con,$sql);
            if($query){
                return ['response'=>'positive','alert'=>'Berhasil Menambahkan Data','redirect'=>$redirect];
            }else{
                echo mysqli_error($con);
                return ['response'=>'negative','alert'=>'Gagal Menambahkan Data'];
            }
    	}

        public function update($table,$values,$where,$whereValues,$redirect){
            global $con;
            $sql   = "UPDATE $table SET $values WHERE $where = '$whereValues'";
            $query = mysqli_query($con,$sql);
                if($query){
                    return ['response'=>'positive','alert'=>'Berhasil update data','redirect'=>$redirect];
                }else{
                    echo mysqli_error($con);
                    return ['response'=>'negative','alert'=>'Gagaal Update Data'];
                }
        }   

    	public function select($table){
            global $con;
            $sql = "SELECT * FROM $table";
            $query = mysqli_query($con,$sql);
            $data = [];
            while($bigData = mysqli_fetch_assoc($query)){
                $data[] = $bigData;
            }
            return $data;
        }

        public function selectCountWhere($table,$namaField,$where){
            global $con;
            $sql = "SELECT COUNT($namaField) as count FROM $table WHERE $where";
            $query = mysqli_query($con,$sql);
            return $data = mysqli_fetch_assoc($query);
        }


        public function validateHtml($field){ 
            $field = htmlspecialchars($field);
            return $field;
        }


        public function delete($table,$where,$whereValues,$redirect){
            global $con;
            $sql = "DELETE FROM $table WHERE $where = '$whereValues'";
            $query = mysqli_query($con,$sql);
            if($query){
                return ['response'=>'positive','alert'=>'Berhasil Menghapus Data','redirect'=>$redirect];
            }else{
                echo mysqli_error($con);
                return ['response'=>'negative','alert'=>'Gagal Menghapus Data'];
            }
        }
    }

 ?>